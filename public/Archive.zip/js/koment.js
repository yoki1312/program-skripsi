let oTable;
$(document).ready(function () {
    $(".test").click(function () {
        var token = document.head.querySelector('meta[name="csrf-token"]');
        window.axios.defaults.headers.common['X-CSRF-TOKEN'] = token.content;

        // send contact form data.
        axios.post('/post-coment', {
            name: $('.preview-name').val(),
            email: $('.preview-email').val(),
            koment: $('#review_comment').val(),
            produk_id: $('.produk').val()
        }).then((response) => {
            location.reload();
        }).catch((error) => {
            console.log(error.response.data)
        });
    });
    $(".add-to-cart").click(function () {
        var token = document.head.querySelector('meta[name="csrf-token"]');
        window.axios.defaults.headers.common['X-CSRF-TOKEN'] = token.content;

        // send contact form data.
        axios.post('/add-to-cart', {
            qty: $('.qty').val(),
            produk_id: $('.produk').val()
        }).then((response) => {
            alert('Succes add Item to Card')
        }).catch((error) => {
            console.log(error.response.data)
        });
    });
    oTable = $('#preorder').DataTable({
        "searching": false,
        "autoWidth": true,
        "responsive": true,
        "processing": true,
        "serverSide": false,
        "paginate": true,
        "displayLength": 5,
        "lengthChange": false,
        "filter": true,
        "bInfo": false,
        ajax: 'datapreorder',
        columns: [{
                data: 'gambar_sampul',
                class: 'text-center',
                render: function (data, type, row) {
                    return '<input type="checkbox" />';
                }
            }, {
                data: 'action',
                class: 'text-center',
                name: 'action',
                orderable: false,
                searchable: false,
                render: function (data, type, row, meta) {
                    return '<button type="button" data-row="' + meta.row + '" class="delete remove-order btn btn-danger btn-sm"> <i class="fa fa-trash" aria-hidden="true"></i></button>';
                },
            },

            {
                data: 'gambar_sampul',
                class: 'text-center',
                render: function (data, type, row) {
                    return '<img width="100px" src="' + 'upload/img_barang/' + data + '"/>';
                }
            },
            {
                data: 'nama_barang'
            },
            {
                data: 'hargaJual'
            },
            {
                data: 'qty'
            },
            {
                data: 'qty',
                render: function (data, type, row) {
                    return parseFloat(row.hargaJual) * parseFloat(row.qty);
                }
            },
        ],
    });
    $(document).on('click', '.remove-order', function () {
        let index = $(this).data('row');
        var data = oTable.row(index).data();
        console.log(data);
        axios.post('/deleted-to-cart/' + data.id_pre_order).then((response) => {
            oTable.ajax.reload(null, false);
        }).catch((error) => {
            console.log(error.response.data)
        });
    });

});
